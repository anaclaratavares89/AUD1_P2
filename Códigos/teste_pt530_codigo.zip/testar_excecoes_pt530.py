"""Teste didático de erros sobre cópia dos 500.000 intangíveis sintéticos.
Executar na pasta contendo intangiveis_sinteticos_500000.csv e excecoes_injetadas.csv.
Dependência: pandas. A base original NÃO é alterada.
"""
from pathlib import Path
import pandas as pd
import json

root=Path(__file__).resolve().parent
# Compatível também com script deslocado para pasta da base
base_path=next((p for p in [root/'intangiveis_sinteticos_500000.csv',root.parent/'Base_Intangivel_TOTVS_2025'/'intangiveis_sinteticos_500000.csv',Path('/content/intangiveis_sinteticos_500000.csv')] if p.exists()),None)
gab_path=next((p for p in [root/'excecoes_injetadas.csv',root.parent/'Base_Intangivel_TOTVS_2025'/'excecoes_injetadas.csv',Path('/content/excecoes_injetadas.csv')] if p.exists()),None)
if not base_path or not gab_path: raise FileNotFoundError('Coloque os dois CSVs ao lado deste script no Colab.')
df=pd.read_csv(base_path,sep=';',low_memory=False)
gab=pd.read_csv(gab_path,sep=';')
assert len(df)==500000 and df.id_componente.is_unique
assert len(gab)==100 and gab.id_componente.is_unique
alterada=df.copy(deep=True)
lookup=pd.Series(alterada.index.values,index=alterada.id_componente)
controle=[]
for row in gab.itertuples(index=False):
    idx=int(lookup.loc[row.id_componente]); old=alterada.loc[idx]
    if row.tipo_erro=='VIDA_UTIL_ZERO':
        assert int(old.vida_util_meses)==int(row.valor_original)
        alterada.at[idx,'vida_util_meses']=int(row.valor_adulterado)
        conta='vida_util_meses'
    elif row.tipo_erro=='AMORTIZACAO_SUPERIOR_AO_CUSTO':
        assert int(old.amortizacao_acumulada_centavos)==int(row.valor_original)
        alterada.at[idx,'amortizacao_acumulada_centavos']=int(row.valor_adulterado)
        conta='amortizacao_acumulada_centavos'
    else: raise ValueError(row.tipo_erro)
    alterada.at[idx,'indicador_erro']='SIM'
    controle.append({'id_componente':row.id_componente,'tipo_erro':row.tipo_erro,'campo_alterado':conta,'valor_original':int(row.valor_original),'valor_adulterado':int(row.valor_adulterado),'variacao_centavos':int(row.valor_adulterado-row.valor_original) if conta.startswith('amortizacao') else 0})

# Os critérios foram escolhidos antes da execução e não consultam o indicador_erro/gabarito.
def testar(d):
    x=d.copy()
    dt=pd.to_datetime(x.data_disponivel,errors='coerce')
    x['T01_diferenca_aritmetica']=(x.custo_centavos-x.amortizacao_acumulada_centavos)!=x.saldo_liquido_centavos
    x['T02_vida_util_nao_positiva']=x.vida_util_meses<=0
    x['T03_amortizacao_superior_custo']=x.amortizacao_acumulada_centavos>x.custo_centavos
    x['T04_data_invalida']=dt.isna()
    x['T05_data_futura']=dt>pd.Timestamp('2025-12-31')
    cols=[c for c in x.columns if c.startswith('T0')]
    x['excecao_detectada']=x[cols].any(axis=1)
    return x,cols

res,checks=testar(alterada)
res['erro_efetivamente_inserido']=res.id_componente.isin(gab.id_componente)
res['classificacao']= 'Sem exceção'
res.loc[res.erro_efetivamente_inserido & res.excecao_detectada,'classificacao']='Verdadeiro positivo'
res.loc[res.erro_efetivamente_inserido & ~res.excecao_detectada,'classificacao']='Falso negativo'
res.loc[~res.erro_efetivamente_inserido & res.excecao_detectada,'classificacao']='Falso positivo'

# Reaplica a mesma seleção aleatória proporcional, idêntica ao procedimento anterior.
import numpy as np
proporcoes=alterada.classe.value_counts().sort_index()
quotas=proporcoes/len(alterada)*300
ns=np.floor(quotas).astype(int)
for classe in (quotas-ns).sort_values(ascending=False).index[:300-int(ns.sum())]: ns.loc[classe]+=1
selecionados=pd.concat([alterada[alterada.classe.eq(classe)].sample(n=int(n),random_state=2025) for classe,n in ns.items()],ignore_index=True)
res_amostra,checks_amostra=testar(selecionados)
res_amostra['erro_efetivamente_inserido']=res_amostra.id_componente.isin(gab.id_componente)
res_amostra['classificacao']='Sem exceção'
res_amostra.loc[res_amostra.erro_efetivamente_inserido & res_amostra.excecao_detectada,'classificacao']='Verdadeiro positivo'
res_amostra.loc[res_amostra.erro_efetivamente_inserido & ~res_amostra.excecao_detectada,'classificacao']='Falso negativo'
res_amostra.loc[~res_amostra.erro_efetivamente_inserido & res_amostra.excecao_detectada,'classificacao']='Falso positivo'

# Não altera originais; saída com intangíveis adulterados separados.
alterada.to_csv(root/'base_adulterada_500000.csv',sep=';',index=False)
res.loc[res.excecao_detectada|res.erro_efetivamente_inserido,['id_componente','classe','custo_centavos','amortizacao_acumulada_centavos','saldo_liquido_centavos',*checks,'excecao_detectada','erro_efetivamente_inserido','classificacao']].to_csv(root/'resultado_teste_censo.csv',sep=';',index=False)
res_amostra[['id_componente','classe',*checks_amostra,'excecao_detectada','erro_efetivamente_inserido','classificacao']].to_csv(root/'resultado_amostra_300.csv',sep=';',index=False)
pd.DataFrame(controle).to_csv(root/'registro_alteracoes.csv',sep=';',index=False)

def metrics(z):
    return {'registros':int(len(z)),'erros_inseridos_na_selecao':int(z.erro_efetivamente_inserido.sum()),'excecoes_sinalizadas':int(z.excecao_detectada.sum()),'verdadeiros_positivos':int(((z.erro_efetivamente_inserido)&z.excecao_detectada).sum()),'falsos_negativos':int((z.erro_efetivamente_inserido&~z.excecao_detectada).sum()),'falsos_positivos':int((~z.erro_efetivamente_inserido&z.excecao_detectada).sum()),'testes_por_regra':{col:int(z[col].sum()) for col in checks}}
rel={'natureza':'SIMULAÇÃO DIDÁTICA — não são registros da TOTVS','censo':metrics(res),'amostra':metrics(res_amostra),'amostra_por_classe':{k:int(v) for k,v in ns.items()},'tipos_de_erros':gab.tipo_erro.value_counts().to_dict(),'amortizacao_adulterada_variacao_rs':float(sum(d['variacao_centavos'] for d in controle)/100),'materialidade_execucao_rs':36469230,'nota':'A variação de amortização é o efeito dos erros inseridos no campo; não é projeção estatística nem distorção real. Erros de vida útil não são monetizados sem novo modelo de amortização.'}
(root/'metricas.json').write_text(json.dumps(rel,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(rel,ensure_ascii=False,indent=2))
